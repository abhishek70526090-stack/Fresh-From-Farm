# Fresh From Farm 2.0

E-commerce + farmer social community starter website.

## Features
- Product shop, category filter and search
- Cart and demo checkout
- Order history using browser localStorage
- Social feed with posts, likes, comments and share
- Create post and sell-product request UI
- Responsive mobile-first design

## GitHub Pages
1. Upload all files to your GitHub repository.
2. Keep `index.html`, `style.css`, and `app.js` in the repository root.
3. GitHub → Settings → Pages → Deploy from branch → main → root.
4. Open the generated Pages URL.

## Production upgrade
For real multi-user accounts, photo/video uploads, persistent products/orders, seller profiles, chat, notifications and online payments, connect Firebase or Supabase and a payment gateway.
